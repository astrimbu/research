---
title: Music
---
The arrangement of sound  
to create some combination of
- form
- harmony
- melody
- rhythm, or otherwise expressive content.