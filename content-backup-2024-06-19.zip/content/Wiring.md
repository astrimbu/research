---
title: Electrical wiring
aliases:
  - electrical wiring
  - electrical work
---

The act of connecting electrical components, devices, or systems together using insulated conductors (copper wires) and other materials like connectors, terminals, and insulators.

---

tags: [[Electricity]]