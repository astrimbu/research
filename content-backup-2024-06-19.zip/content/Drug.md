---
title: Drug
tags:
  - 🗺️
---

- [[Cannabis#THC|Cannabis]]
- [[Coffee#Caffeine|Coffee]]
- [[Tea]]
- [[Alcohol]]
- [[Psilocybin]]

---

tags: [[Consciousness]] - [[Psychology]] - [[Biochemistry]]