---
title: Machine Learning
aliases:
  - machine learning
---

**Machine Learning (ML)**: A subset of [[AI]] that focuses on algorithms learning from data to make predictions or decisions.

---

tags: [[Computer Science]] - [[AI]]