---
title: Cannabis
aliases:
  - marijuana
  - weed
---

### THC


---

tags: [[Drug]] - [[Nature]]