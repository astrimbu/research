---
title: Piano repertoire
---
- Beethoven Sonata op.13 no.8 _"Pathétique"_
- Rachmaninoff Prelude op.3 no.2
- Chopin Nocturne op.55 no.1
- C.P.E. Bach _"Solfeggietto"_
- Chopin Prelude op.28 no.15 _"Raindrop"_
- Debussy _"Clair De Lune"_
- Joplin _"Maple Leaf Rag"_
- Joplin _"Bethena Waltz"_
- Chopin Waltz op.64 no.1 _"Minute"_
- Chopin Prelude op.28 no.20
- Beethoven _"Für Elise"_
- Kolling op.147 no.2 _"Flying Leaves"_
- Rachmaninoff Prelude op.23 no.5
- Kapustin Etude op.40 no.6 _"Pastorale"_

---

#TODO:
- [ ] Links to YouTube performances
- [ ] Sheet music pdf if possible
- [ ] Each piece as individual note

---

tags: [[Piano]]