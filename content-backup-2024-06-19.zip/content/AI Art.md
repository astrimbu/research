---
title: Artificial Intelligence Art
aliases:
  - cgi
  - generative art
  - artificial intelligence art
---

- [ ] Add ai art (noway!)


- **Digital Art**: Creating unique visual art pieces for galleries, exhibitions, or personal collections.
- **Design**: Generating patterns, textures, and design elements for fashion, architecture, and product design.
- **Media Production**: Producing visual effects, animations, and digital assets for films, video games, and virtual reality experiences.

---

tags: [[Computer Science]] - [[AI]]