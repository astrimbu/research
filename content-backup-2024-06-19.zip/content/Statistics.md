


- [ ] Discussion in [[OSRS]] terms


---

tags: [[Mathematics]] - [[OSRS]]