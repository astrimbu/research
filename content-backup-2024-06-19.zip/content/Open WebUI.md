---
title: Open WebUI
---
Self-hosted ChatGPT-style web user interface that supports Ollama and other LLM runners and APIs.


---

tags: [[AI]] - [[LLM]]