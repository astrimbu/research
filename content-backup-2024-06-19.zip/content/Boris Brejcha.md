---
title: Boris Brejcha
aliases:
  - boris
  - brejcha
---

Boris Brejcha is a German DJ and record producer.  
He describes his music style as "high-tech minimal."  

It sounds really good with headphones.  


---

tags: [[Music]]