---
title: Research
tags:
  - 🗺️
---

All content summarized with GPT-4o

Computer Science papers  
- [[Attention paper]]
- [[BERT paper]]
- [[CLIP paper]]
- [[ControlNet paper]]
- [[LLM-Pruner paper]]
- [[LLMs are in 1.58 bits]]
- [[LMs few-shot learners]]
- [[LMs general-purpose interfaces]]
- [[LMs unsupervised multitask learners]]
- [[NeRF paper]]
- [[SD3 Paper]]

Philosophy books  
- [[Meditations on First Philosophy]]
- [[Critique of Pure Reason]]
- [[Being and Time]]

---

tags: [[Computer Science]]