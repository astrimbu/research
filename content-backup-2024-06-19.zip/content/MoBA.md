---
title: MoBA
aliases:
  - Multiplayer online Battle Arena
---
Multiplayer
Online
Battle
Arena

---

tags: [[Video Game]]