---
title: Simulation hypothesis
aliases: []
---

The simulation hypothesis proposes that what humans experience as the world is actually a simulated reality, such as a computer simulation in which humans themselves are constructs.

- https://en.wikipedia.org/wiki/Simulation_hypothesis

See also:  
- Plato's [[allegory of the cave]]


---

tags: [[Philosophy]]