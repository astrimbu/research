---
title: Snarky Puppy
---

Snarky Puppy (2004) is an American jazz fusion band led by bassist Michael League.  


Snarky Puppy combines a variety of:
- jazz
- rock
- world music
- funk


They have won five Grammy Awards.


---

tags: [[Music]]