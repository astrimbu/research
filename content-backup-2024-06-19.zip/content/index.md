---
title: Welcome
---
Welcome to my digital garden 🌱

I'm using this space to:
- take notes on whatever I'm attending to atm
- organize my notes
- archive some thoughts
- motivate myself to learn new things
- refresh old knowledge

Tools used are [Obsidian](https://obsidian.md/) for editing content, [Quartz](https://quartz.jzhao.xyz/) for SSG, GitHub Pages for hosting.


> [!WARNING] 404 🌱
> ✍️(◔◡◔)
> Content is being written
> Please stand by 


[[Computer Science]]
[[Language]]
[[AI]]