---
title: Illusory truth effect
tags:
  - 🖥️
---

Repetition makes false information believable.  

Repeated exposure to a statement increases its perceived truth, even if the statement is false.  

The illusory truth effect is a cognitive bias that describes the phenomenon where repeated exposure to a statement increases the likelihood that people will believe it to be true, even if it is false. This effect occurs because familiarity with a statement makes it easier to process, and this ease of processing (also known as cognitive fluency) is often mistakenly interpreted as a signal of truth.  

Key aspects:  

1. **Repetition**: The more often a statement is repeated, the more familiar it becomes, leading to greater perceived truthfulness.
2. **Cognitive Fluency**: Repeated statements are easier to process mentally, and this fluency is often unconsciously equated with accuracy.
3. **Influence on Beliefs**: The effect can influence people's beliefs and perceptions, leading them to accept false information as true if they encounter it frequently enough.
4. **Impact on Decision-Making**: This bias can affect decision-making processes, as individuals might base their judgments on information they incorrectly believe to be true.
5. **Resistance to Correction**: Once a false belief has been established due to the illusory truth effect, it can be difficult to correct, even when presented with accurate information.

The illusory truth effect has significant implications in various domains, such as politics, marketing, and media, where repeated exposure to certain messages can shape public opinion and beliefs. Understanding this bias is crucial for critically evaluating information and recognizing the potential influence of repeated statements on one's beliefs and decisions.  