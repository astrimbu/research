---
title: Zen and the Art of Motorcycle Maintenance
aliases:
  - Zen and the Art of Motorcycle Maintenance
---

A great philosophical novel by Robert M. Pirsig

"What is quality?"  
Quality can not be bought, only made.  
Quality is consciousness applied.  

---

tags: [[Book]] - [[Philosophy]]