---
title: Large Language Model
aliases:
  - large language model
---

**Large Language Models (LLMs)**: A type of ML model designed to understand and generate human language based on patterns learned from vast amounts of text data.

### Tools
OpenWebUI, Llama3, Continue (LLM in VSCode), Ollama,

---

tags: [[Computer Science]] - [[Language]] - [[ML]] - [[AI]]