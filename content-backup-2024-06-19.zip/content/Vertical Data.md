---
title: Vertical Data
aliases:
  - VeDa
---



---

tags: [[Computer Science]] - [[ACRE]] - [[ML]]