---
title: Calculus
aliases:
  - calc
---



---

tags: [[Mathematics]]