---
title: Quotes
aliases: quotation
---

> "First rule in government spending: Why build one when you can have two, twice the price?"
	S. R. Hadden
		Contact (1997)
