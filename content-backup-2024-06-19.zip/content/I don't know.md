---
title: I don't know
---
On the first day of [[Discrete Math]] class, my professor gave us a not-so-short speech about one of his core beliefs:  

>If you don't know, say "I don't know."  

He repeated this every lecture. Years later, I think this is good wisdom.

Saying "I don't know" can help people avoid overconfidence, and to remain open to new information and perspectives.  

Admitting ignorance can foster metacognitive skills, such as self-awareness, reflection, and evaluation.  

Saying "I don't know" can lead to open-ended inquiry, where learners are more likely to explore new ideas, consider alternative perspectives, and challenge their own assumptions. This openness can facilitate a deeper understanding of the subject matter and promote creative problem-solving.  

---

tags: [[Psychology]]