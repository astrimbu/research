---
title: Plastic
aliases:
  - polymer
---
