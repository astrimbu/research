---
title: Poison Ivy
---



---

tags: [[Nature]]