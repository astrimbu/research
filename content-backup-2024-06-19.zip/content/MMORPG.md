---
title: MMORPG
aliases:
  - Massively Multiplayer Online Role-Playing Game
---
Massively
Multiplayer
Online
Role-
Playing
Game

---

tags: [[Video Game]]