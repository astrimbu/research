---
title: PFAS
aliases:
  - forever chemical
  - polyfluoroalkyl substances
---
Per- | Poly-  
Fluoro-  
Alkyl  
Substances  


---

tags: [[Plastic]]