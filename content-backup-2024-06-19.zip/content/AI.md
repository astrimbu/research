---
title: Artificial Intelligence
aliases:
  - Artificial Intelligence
tags:
  - 🗺️
---

**Artificial Intelligence (AI)**: A broad term for systems that can perform tasks that typically require human intelligence. This includes reasoning, learning, problem-solving, understanding natural language, and more.

- [[Stable Diffusion]]
- [[Comfy UI]]
- [[AI Art]]
- [[LLM]]

---

tags: [[Computer Science]] - [[ML]] - [[AI Art]]