---
title: Emergence
---

Complexity out of simplicity.

Small objects collect into larger ones that follow their own laws.

A phenomenon where larger entities, patterns, or properties arise through interactions among smaller or simpler entities that themselves do not exhibit such properties.


---

tags: [[Philosophy]] - [[Computer Science]] - [[AI]] - [[Brain]]