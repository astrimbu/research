---
title: Computer Science
aliases: []
tags:
  - 🗺️
---

- [[AI]]
- [[LLM]]
- [[ML]]
- [[NLP]]
- [[Research]]
- [[Web Development]]

 - [[Discrete mathematics]]
 - [[Video Game]]
