---
title: Neural Net
aliases:
  - nn
---



---

tags: [[Computer Science]] - [[ML]]